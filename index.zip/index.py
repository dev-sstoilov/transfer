﻿#!/usr/bin/env python3
import subprocess
import sys

cmd = [sys.executable, "-m", "pip", "install", "pytz", "requests", "--break-system-packages"]
try:
    subprocess.run(cmd, check=True)
except subprocess.CalledProcessError as e:
    print("Installation failed:", e)
import curses
import time
import threading
import random
import requests
from datetime import datetime
import pytz
import signal
import sys
import json
#setup: pip install requests pytz
# ==================== FACE DEFINITIONS ====================
FACES = {
    'LOOK_R': '( ⚆_⚆)',
    'LOOK_L': '(☉_☉ )',
    'LOOK_R_HAPPY': '( ◕‿◕)',
    'LOOK_L_HAPPY': '(◕‿◕ )',
    'SLEEP': '(⇀‿‿↼)',
    'SLEEP2': '(≖‿‿≖)',
    'AWAKE': '(◕‿‿◕)',
    'BORED': '(-__-)',
    'INTENSE': '(°▃▃°)',
    'COOL': '(⌐■_■)',
    'HAPPY': '(•‿‿•)',
    'GRATEFUL': '(^‿‿^)',
    'EXCITED': '(ᵔ◡◡ᵔ)',
    'MOTIVATED': '(☼‿‿☼)',
    'DEMOTIVATED': '(≖__≖)',
    'SMART': '(✜‿‿✜)',
    'LONELY': '(ب__ب)',
    'SAD': '(╥☁╥ )',
    'ANGRY': "(-_-')",
    'FRIEND': '(♥‿‿♥)',
    'BROKEN': '(☓‿‿☓)'
}

# ==================== DYNAMIC CONTENT CLASSES ====================
class ChristmasTree:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.idx = 0
        self.colors = [
            curses.COLOR_CYAN,
            curses.COLOR_RED,
            curses.COLOR_MAGENTA,
            curses.COLOR_GREEN,
            curses.COLOR_YELLOW
        ]
        
        # Christmas tree template (simplified version)
        self.tree_template = [
            "         *",
            "        / \\",
            "       /   \\",
            "      /_   _\\",
            "        / \\",
            "       /   \\",
            "      /_   _\\",
            "        / \\",
            "       /   \\",
            "      /_   _\\",
            "       /___\\",
            "        |||",
            "        |||"
        ]
        
        # Light positions in the tree (row, col, color_index)
        self.lights = [
            (1, 8, 0), (2, 7, 1), (2, 9, 2),
            (4, 7, 3), (4, 9, 0), (6, 7, 1),
            (6, 9, 2), (8, 7, 3), (8, 9, 0)
        ]
    
    def get_frame(self, is_christmas):
        frame = []
        tree_height = len(self.tree_template)
        start_y = max(0, (self.height - tree_height) // 2)
        
        # Add empty lines if needed
        for _ in range(start_y):
            frame.append(" " * self.width)
        
        for i, line in enumerate(self.tree_template):
            display_line = list(line)
            
            # Add lights
            for light_row, light_col, color_idx in self.lights:
                if i == light_row:
                    # Rotate colors
                    actual_idx = (color_idx + self.idx) % len(self.colors)
                    if light_col < len(display_line):
                        display_line[light_col] = 'o'
            
            # Center the tree
            padding = max(0, (self.width - len(display_line)) // 2)
            frame.append(" " * padding + "".join(display_line))
        
        # Add Christmas message if it's Christmas day
        if is_christmas:
            messages = [
                "Merry Christmas!",
                "From Kitchen AI",
                "curl ysap.sh"
            ]
            
            message_y = start_y + tree_height + 1
            for i, msg in enumerate(messages):
                if message_y + i < self.height:
                    padding = max(0, (self.width - len(msg)) // 2)
                    frame.append(" " * padding + msg)
        
        # Fill remaining height
        while len(frame) < self.height:
            frame.append(" " * self.width)
        
        # Trim to exact height
        frame = frame[:self.height]
        
        # Update light index
        self.idx = (self.idx + 1) % len(self.colors)
        
        return frame

class MatrixRain:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.drops = [0] * width
        self.chars = [chr(i) for i in range(0x30A1, 0x30F6)]  # Japanese katakana
        self.chars.extend([chr(i) for i in range(0x0041, 0x005A)])  # A-Z
        self.chars.extend([chr(i) for i in range(0x0061, 0x007A)])  # a-z
        self.chars.extend([str(i) for i in range(10)])  # 0-9
    
    def get_frame(self, is_christmas):
        frame = []
        
        for row in range(self.height):
            line_chars = []
            for col in range(self.width):
                if self.drops[col] > 0 and random.random() > 0.3:
                    char = random.choice(self.chars)
                    # Vary brightness based on drop position
                    if row == self.drops[col] - 1:
                        char = char  # Brightest
                    elif row == self.drops[col] - 2:
                        char = char.lower() if char.isupper() else char
                    else:
                        char = char.lower() if random.random() > 0.5 else '.'
                    line_chars.append(char)
                else:
                    line_chars.append(' ')
            
            frame.append("".join(line_chars))
        
        # Update drops
        for i in range(self.width):
            if self.drops[i] <= 0 or random.random() > 0.95:
                self.drops[i] = self.height
            self.drops[i] -= 1
        
        return frame

# ==================== UTILITY FUNCTIONS ====================
def get_bulgaria_time():
    """Get current time in Bulgaria timezone"""
    try:
        # Try to get time from worldtimeapi
        response = requests.get('http://worldtimeapi.org/api/timezone/Europe/Sofia', timeout=3)
        if response.status_code == 200:
            data = response.json()
            return datetime.fromisoformat(data['datetime'].replace('Z', '+00:00'))
    except:
        pass
    
    # Fallback to system time with Sofia timezone
    sofia_tz = pytz.timezone('Europe/Sofia')
    return datetime.now(sofia_tz)

def is_christmas_day():
    current_time = get_bulgaria_time()
    return current_time.month == 12


def calculate(current_time):
    """
    Example calculate function that returns face and text based on time
    Replace this with your actual calculation logic
    """
    hour = current_time.hour
    minute = current_time.second
    
    # Example logic: change face based on time
    if hour < 6:
        face = 'SLEEP'
        text = "Sleeping... zzz"
    elif hour < 12:
        if minute % 2 == 0:
            face = 'LOOK_R_HAPPY'
        else:
            face = 'HAPPY'
        text = f"Good morning! Time: {current_time.strftime('%H:%M:%S')}"
    elif hour < 18:
        face = 'AWAKE'
        text = f"Afternoon session. Seconds: {current_time.second}"
    elif hour < 22:
        face = 'BORED'
        text = f"Evening hours... {hour}:{current_time.minute:02d}"
    else:
        face = 'SLEEP2'
        text = "Late night mode"
    
    # Every 30 seconds, change to a random face
    if current_time.second % 30 == 0:
        face = random.choice(list(FACES.keys()))
    
    return face, text

def wrap_text(text, width):
    """Wrap text to fit within specified width"""
    words = text.split()
    lines = []
    current_line = []
    
    for word in words:
        if len(' '.join(current_line + [word])) <= width:
            current_line.append(word)
        else:
            if current_line:
                lines.append(' '.join(current_line))
            current_line = [word]
    
    if current_line:
        lines.append(' '.join(current_line))
    
    return lines

# ==================== MAIN DISPLAY CLASS ====================
class TerminalDisplay:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        self.running = True
        self.lock = threading.Lock()
        
        # Initialize colors if available
        self.has_colors = curses.has_colors()
        if self.has_colors:
            curses.start_color()
            curses.use_default_colors()
            # Define some color pairs
            for i in range(1, 8):
                curses.init_pair(i, i, -1)
        
        # Current state
        self.current_face = 'AWAKE'
        self.current_text = "Initializing..."
        self.dynamic_content = []
        self.is_christmas = False
        
        # Get initial screen size
        self.update_screen_size()
        
        # Start update threads
        self.start_threads()
        
        # Setup signal handler for Ctrl+C
        signal.signal(signal.SIGINT, self.signal_handler)
    
    def update_screen_size(self):
        """Update screen dimensions and recalculate layout"""
        height, width = self.stdscr.getmaxyx()
        self.height = height
        self.width = width
        
        # Calculate proportional layout (40% left, 60% right)
        self.left_width = int(width * 0.4)
        self.right_width = width - self.left_width
        
        # Right panel: 60% text, 40% dynamic
        self.text_height = int(height * 0.6)
        self.dynamic_height = height - self.text_height
        
        # Create subwindows
        self.left_win = curses.newwin(height, self.left_width, 0, 0)
        self.text_win = curses.newwin(self.text_height, self.right_width, 0, self.left_width)
        self.dynamic_win = curses.newwin(self.dynamic_height, self.right_width, 
                                        self.text_height, self.left_width)
        
        # Initialize dynamic content based on time of year
        self.is_christmas = is_christmas_day()
        if self.is_christmas:
            self.dynamic_content_obj = ChristmasTree(self.right_width, self.dynamic_height)
        else:
            self.dynamic_content_obj = MatrixRain(self.right_width, self.dynamic_height)
    
    def start_threads(self):
        """Start background update threads"""
        # Thread for face and text updates (max 5 seconds)
        self.face_thread = threading.Thread(target=self.update_face_text, daemon=True)
        self.face_thread.start()
        
        # Thread for dynamic content updates (max 5 seconds)
        self.dynamic_thread = threading.Thread(target=self.update_dynamic_content, daemon=True)
        self.dynamic_thread.start()
    
    def update_face_text(self):
        """Update face and text periodically"""
        while self.running:
            try:
                current_time = get_bulgaria_time()
                face_name, text = calculate(current_time)
                
                with self.lock:
                    self.current_face = face_name
                    self.current_text = text
                
                # Update every 1-5 seconds (random to make it more organic)
                time.sleep(random.uniform(1, 5))
                
            except Exception as e:
                with self.lock:
                    self.current_text = f"Error: {str(e)}"
                time.sleep(5)
    
    def update_dynamic_content(self):
        """Update dynamic content periodically"""
        while self.running:
            try:
                # Check if it's Christmas (could change if program runs across midnight)
                current_is_christmas = is_christmas_day()
                if current_is_christmas != self.is_christmas:
                    with self.lock:
                        self.is_christmas = current_is_christmas
                        if self.is_christmas:
                            self.dynamic_content_obj = ChristmasTree(self.right_width, self.dynamic_height)
                        else:
                            self.dynamic_content_obj = MatrixRain(self.right_width, self.dynamic_height)
                
                # Get new frame from dynamic content object
                new_content = self.dynamic_content_obj.get_frame(self.is_christmas)
                
                with self.lock:
                    self.dynamic_content = new_content
                
                # Update at different rates based on content
                if self.is_christmas:
                    time.sleep(1)  # Christmas tree updates every second
                else:
                    time.sleep(0.1)  # Matrix rain updates faster
                    
            except Exception as e:
                with self.lock:
                    self.dynamic_content = [f"Dynamic error: {str(e)}"]
                time.sleep(5)
    
    def draw_borders(self):
        """Draw borders around each section"""
        # Left border
        for y in range(self.height):
            self.stdscr.addch(y, self.left_width - 1, curses.ACS_VLINE)
        
        # Horizontal border between text and dynamic
        for x in range(self.left_width, self.width):
            self.stdscr.addch(self.text_height - 1, x, curses.ACS_HLINE)
        
        # Corner characters
        self.stdscr.addch(self.text_height - 1, self.left_width - 1, curses.ACS_LTEE)
        self.stdscr.addch(self.text_height - 1, self.width - 1, curses.ACS_RTEE)
        
        # Top and bottom borders
        for x in range(self.width):
            self.stdscr.addch(0, x, curses.ACS_HLINE)
            self.stdscr.addch(self.height - 1, x, curses.ACS_HLINE)
        
        # Vertical borders on sides
        for y in range(self.height):
            self.stdscr.addch(y, 0, curses.ACS_VLINE)
            self.stdscr.addch(y, self.width - 1, curses.ACS_VLINE)
        
        # Corners
        self.stdscr.addch(0, 0, curses.ACS_ULCORNER)
        self.stdscr.addch(0, self.width - 1, curses.ACS_URCORNER)
        self.stdscr.addch(self.height - 1, 0, curses.ACS_LLCORNER)
        self.stdscr.addch(self.height - 1, self.width - 1, curses.ACS_LRCORNER)
    
    def draw_left_panel(self):
        """Draw the face in the left panel"""
        self.left_win.clear()
        
        try:
            face_char = FACES.get(self.current_face, FACES['AWAKE'])
            
            # Calculate centered position
            face_lines = face_char.split('\n') if '\n' in face_char else [face_char]
            face_height = len(face_lines)
            face_width = max(len(line) for line in face_lines)
            
            start_y = max(0, (self.height - face_height) // 2)
            start_x = max(0, (self.left_width - face_width) // 2)
            
            # Draw the face
            for i, line in enumerate(face_lines):
                if start_y + i < self.height:
                    x_pos = max(0, start_x)
                    try:
                        self.left_win.addstr(start_y + i, x_pos, line)
                    except:
                        pass  # Ignore drawing errors at screen edges
            
            self.left_win.refresh()
        except:
            pass
    
    def draw_text_panel(self):
        """Draw the text in the right top panel"""
        self.text_win.clear()
        
        try:
            # Wrap text to fit panel
            wrapped_text = wrap_text(self.current_text, self.right_width - 2)
            
            # Calculate starting position (centered vertically)
            text_height = min(len(wrapped_text), self.text_height - 2)
            start_y = max(0, (self.text_height - text_height) // 2)
            
            # Draw text lines
            for i, line in enumerate(wrapped_text):
                if i < self.text_height - 2 and start_y + i < self.text_height:
                    x_pos = max(0, (self.right_width - len(line)) // 2)
                    try:
                        self.text_win.addstr(start_y + i, x_pos, line)
                    except:
                        pass
            
            self.text_win.refresh()
        except:
            pass
    
    def draw_dynamic_panel(self):
        """Draw the dynamic content in the right bottom panel"""
        self.dynamic_win.clear()
        
        try:
            # Get current dynamic content
            with self.lock:
                dynamic_lines = self.dynamic_content
            
            # Calculate starting position
            dyn_height = min(len(dynamic_lines), self.dynamic_height)
            start_y = max(0, (self.dynamic_height - dyn_height) // 2)
            
            # Draw dynamic content
            for i, line in enumerate(dynamic_lines):
                if i < self.dynamic_height and start_y + i < self.dynamic_height:
                    # Ensure line fits in width
                    display_line = line[:self.right_width - 1]
                    x_pos = max(0, (self.right_width - len(display_line)) // 2)
                    try:
                        # Apply colors for Christmas tree
                        if self.is_christmas and isinstance(self.dynamic_content_obj, ChristmasTree):
                            # Simple color coding for Christmas tree
                            for j, char in enumerate(display_line):
                                if char == '*':
                                    self.dynamic_win.addch(start_y + i, x_pos + j, char, 
                                                         curses.color_pair(3))  # Yellow
                                elif char == 'o':
                                    color_idx = (i + j + self.dynamic_content_obj.idx) % len(self.dynamic_content_obj.colors)
                                    self.dynamic_win.addch(start_y + i, x_pos + j, char,
                                                         curses.color_pair(color_idx + 1))
                                elif char in '/\\_|-':
                                    self.dynamic_win.addch(start_y + i, x_pos + j, char,
                                                         curses.color_pair(2))  # Green
                                else:
                                    self.dynamic_win.addch(start_y + i, x_pos + j, char)
                        else:
                            # Matrix rain with green color
                            for j, char in enumerate(display_line):
                                if char != ' ':
                                    self.dynamic_win.addch(start_y + i, x_pos + j, char,
                                                         curses.color_pair(2))  # Green
                                else:
                                    self.dynamic_win.addch(start_y + i, x_pos + j, char)
                    except:
                        pass
            
            self.dynamic_win.refresh()
        except:
            pass
    
    def signal_handler(self, signum, frame):
        """Handle Ctrl+C gracefully"""
        self.running = False
        time.sleep(0.1)  # Give threads time to finish
        sys.exit(0)
    
    def run(self):
        """Main display loop"""
        last_size = (self.height, self.width)
        
        while self.running:
            try:
                # Check for screen resize
                current_height, current_width = self.stdscr.getmaxyx()
                if (current_height, current_width) != last_size:
                    self.update_screen_size()
                    last_size = (current_height, current_width)
                
                # Clear screen
                self.stdscr.clear()
                
                # Draw borders
                self.draw_borders()
                
                # Draw each panel
                self.draw_left_panel()
                self.draw_text_panel()
                self.draw_dynamic_panel()
                
                # Refresh main screen
                self.stdscr.refresh()
                
                # Small delay to prevent high CPU usage
                time.sleep(0.05)
                
            except KeyboardInterrupt:
                self.running = False
                break
            except Exception as e:
                # If something goes wrong, show error and continue
                try:
                    self.stdscr.clear()
                    self.stdscr.addstr(0, 0, f"Error: {str(e)}")
                    self.stdscr.refresh()
                    time.sleep(5)
                except:
                    pass

# ==================== MAIN EXECUTION ====================
def main(stdscr):
    # Setup terminal
    curses.curs_set(0)  # Hide cursor
    curses.noecho()     # Don't echo keypresses
    stdscr.nodelay(1)   # Non-blocking input
    
    # Create and run display
    display = TerminalDisplay(stdscr)
    display.run()

if __name__ == "__main__":
    # Install exception handler
    try:
        curses.wrapper(main)
    except KeyboardInterrupt:
        print("\nProgram terminated by user")
        sys.exit(0)
    except Exception as e:
        print(f"Fatal error: {e}")
        sys.exit(1)