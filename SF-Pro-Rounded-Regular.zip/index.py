﻿import pygame
import time
import random
from datetime import datetime, timedelta
from PIL import Image, ImageDraw, ImageFont
import os
import requests

# --- Configuration ---
FPS = 5
TYPEWRITER_SPEED = 5
UPDATE_INTERVAL = 5.0

FACE_FONT_PATHS = ["seguisym.ttf"]
FONT_TEXT_PATH = "./Comfortaa-Bold.ttf"
FACE_FONT_SIZE = 120
HEADER_FONT_SIZE = 18
PROMPT_FONT_SIZE = 20
MSG_FONT_SIZE = 20
BOTTOM_FONT_SIZE = 18
MARGIN_X = 10
TOP_BAR_H = 36
BOTTOM_BAR_H = 36
MIDDLE_PADDING = 12

FACES = {
    'AWAKE': '( ^_^ )',
    'HAPPY': '( ^‿^ )',
    'SLEEP': '( -_- )',
    'LOOK_R': '( ⚆_⚆)',
    'LOOK_L': '(☉_☉ )',
    'COOL': '(⌐■_■)',
    'KAWAII': '( ^.^ )',
}

# ---------------------------------------------------------------------
# Font utilities
# ---------------------------------------------------------------------
def load_font(path, size, fallback=True):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        if fallback:
            return ImageFont.load_default()
        raise

def font_has_glyph(pil_font, char):
    try:
        mask = pil_font.getmask(char, mode='L')
        im = Image.frombytes('L', mask.size, bytes(mask))
        return im.getbbox() is not None
    except Exception:
        return False

def get_best_font_for_char(char, fonts):
    for f in fonts:
        if font_has_glyph(f, char):
            return f
    return None

# ---------------------------------------------------------------------
# Pwnagotchi UI
# ---------------------------------------------------------------------
class PwnagotchiUI:
    def __init__(self):
        # Force SDL2 fullscreen on HDMI
        if os.name == "nt":
            os.environ["SDL_VIDEODRIVER"] = "windows"
        # else: keep default for other OS
        pygame.init()
        self.screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
        self.width, self.height = self.screen.get_size()
        pygame.display.set_caption("Pwnagotchi HDMI UI")

        self.last_clock_sync = time.time()
        self.bulgaria_time = datetime.utcnow() + timedelta(hours=2)

        # Load fonts
        self.face_fonts = [load_font(fp, FACE_FONT_SIZE, fallback=False) for fp in FACE_FONT_PATHS if os.path.exists(fp)]
        if not self.face_fonts:
            self.face_fonts = [ImageFont.load_default()]

        self.text_font = load_font(FONT_TEXT_PATH, MSG_FONT_SIZE)
        self.header_font = load_font(FONT_TEXT_PATH, HEADER_FONT_SIZE)
        self.prompt_font = load_font(FONT_TEXT_PATH, PROMPT_FONT_SIZE)
        self.bottom_font = load_font(FONT_TEXT_PATH, BOTTOM_FONT_SIZE)
        self.sf_pro_font = load_font("./SF-Pro-Rounded-Regular.otf", FACE_FONT_SIZE, fallback=False)

        self.current_face_key = 'AWAKE'
        self.current_face = FACES[self.current_face_key]
        self.current_message = "Welcome!"
        self.displayed_message = ""
        self.typewriter_chars_typed = 0
        self.is_typing_finished = False
        self.last_typewriter_update = time.time()
        self.message_finished_time = 0
        self.cursor_visible = True
        self.last_blink_time = time.time()

        self.update_face_and_message(force=True)

    # -------------------------
    def get_bulgaria_time_str(self):
        elapsed = time.time() - self.last_clock_sync
        now = self.bulgaria_time + timedelta(seconds=elapsed)
        return now.strftime("%H:%M:%S")

    # -------------------------
    def update_face_and_message(self, force=False):
        def fetch_security_event():
            try:
                kev = requests.get(
                    "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json",
                    timeout=5
                ).json()
                items = kev.get("vulnerabilities", [])
                if items:
                    item = random.choice(items)
                    desc = f"0-day: {item.get('vulnerabilityName','Unknown')} ({item.get('dateAdded','Unknown')})"
                    severity = "critical"
                else:
                    desc = "No new public exploits today."
                    severity = "low"
                return desc, severity
            except:
                return "No threat intelligence available.", "low"

        t = time.time()
        if force or (self.is_typing_finished and t - self.message_finished_time >= UPDATE_INTERVAL):
            msg, sev = fetch_security_event()
            self.current_face_key = {"critical":"COOL","high":"LOOK_L","medium":"LOOK_R"}.get(sev,"AWAKE")
            self.current_face = FACES[self.current_face_key]
            self.current_message = msg
            self.displayed_message = ""
            self.typewriter_chars_typed = 0
            self.is_typing_finished = False
            self.message_finished_time = 0
            self.last_typewriter_update = time.time()

    # -------------------------
    def update_typewriter(self):
        now = time.time()
        if self.typewriter_chars_typed < len(self.current_message):
            delta = int((now - self.last_typewriter_update) * TYPEWRITER_SPEED)
            if delta > 0:
                new_count = min(self.typewriter_chars_typed + delta, len(self.current_message))
                self.typewriter_chars_typed = new_count
                self.displayed_message = self.current_message[:new_count]
                self.last_typewriter_update = now
                if new_count == len(self.current_message):
                    self.is_typing_finished = True
                    self.message_finished_time = time.time()

    # -------------------------
    def update_blink(self):
        if time.time() - self.last_blink_time >= 0.7:
            self.cursor_visible = not self.cursor_visible
            self.last_blink_time = time.time()

    # -------------------------
    def render_face_char_by_char(self, draw, face_text, x, y):
        cur_x = x
        for ch in face_text:
            font = self.sf_pro_font if ch=='■' else get_best_font_for_char(ch,self.face_fonts) or self.face_fonts[0]
            w = draw.textbbox((0,0),ch,font=font)[2]
            draw.text((cur_x,y),ch,font=font,fill="black")
            cur_x += w + 2

    # -------------------------
    def render_layout(self):
        img = Image.new("RGB", (self.width,self.height), "white")
        draw = ImageDraw.Draw(img)

        # Top bar
        tl = "CH *  APS 4 (9)"
        tr = "UP " + self.get_bulgaria_time_str()
        draw.text((MARGIN_X,6), tl, font=self.header_font, fill="black")
        draw.text((self.width - draw.textbbox((0,0),tr,font=self.header_font)[2]-MARGIN_X,6), tr, font=self.header_font, fill="black")
        draw.line([(MARGIN_X, TOP_BAR_H-6),(self.width-MARGIN_X,TOP_BAR_H-6)], fill="black", width=2)

        # Face
        middle_top = TOP_BAR_H + MIDDLE_PADDING
        middle_bottom = self.height - BOTTOM_BAR_H - MIDDLE_PADDING
        mh = middle_bottom - middle_top
        left_w = int(self.width*0.45)
        right_x = left_w + MARGIN_X

        face_text = self.current_face
        tw = sum(draw.textbbox((0,0),ch,font=get_best_font_for_char(ch,self.face_fonts) or self.face_fonts[0])[2] + 2 for ch in face_text)
        fx = (left_w - tw)//2 + 40
        fy = middle_top + (mh - FACE_FONT_SIZE)//2
        self.render_face_char_by_char(draw, face_text, fx, fy)

        # Prompt & message
        prompt = "AI> "
        px = right_x
        py = middle_top + 8
        draw.text((px,py),prompt,font=self.prompt_font,fill="black")
        p_w = draw.textbbox((0,0),prompt,font=self.prompt_font)[2]
        if self.cursor_visible and not self.is_typing_finished:
            draw.rectangle([px+p_w+4, py, px+p_w+4+self.prompt_font.size//2, py+self.prompt_font.size], fill="black")

        # Message wrap
        msg_x = right_x
        msg_y = py + self.prompt_font.size + 6
        max_w = self.width - right_x - MARGIN_X
        lines=[]
        for p in (self.displayed_message or self.current_message).split("\n"):
            cur=""
            for w_ in p.split(" "):
                t=(cur+" "+w_).strip() if cur else w_
                if draw.textbbox((0,0),t,font=self.text_font)[2]<=max_w:
                    cur=t
                else:
                    if cur: lines.append(cur)
                    cur=w_
            if cur: lines.append(cur)
        for i,line in enumerate(lines[:6]):
            draw.text((msg_x,msg_y+i*(self.text_font.size+6)),line,font=self.text_font,fill="black")

        # Bottom bar
        by = self.height - BOTTOM_BAR_H + 6
        draw.line([(MARGIN_X,by),(self.width-MARGIN_X,by)], fill="black", width=2)
        draw.text((MARGIN_X, by+6), "PWND 1 (18) [PS4-086313EAB731]", font=self.bottom_font, fill="black")
        return img

    # -------------------------
    def pil_to_pygame(self, img):
        return pygame.image.fromstring(img.tobytes(), img.size, img.mode)

    # -------------------------
    def run(self):
        clock = pygame.time.Clock()
        running = True
        while running:
            for ev in pygame.event.get():
                if ev.type==pygame.QUIT or (ev.type==pygame.KEYDOWN and ev.key==pygame.K_ESCAPE):
                    running=False

            self.update_face_and_message()
            self.update_typewriter()
            self.update_blink()

            surf = self.pil_to_pygame(self.render_layout())
            self.screen.blit(surf,(0,0))
            pygame.display.flip()
            clock.tick(FPS)
        pygame.quit()

# ---------------------------------------------------------------------
if __name__=="__main__":
    PwnagotchiUI().run()
