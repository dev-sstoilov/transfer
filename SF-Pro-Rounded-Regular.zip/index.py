﻿import pygame
import time
import random
import threading
from datetime import datetime, timedelta
from PIL import Image, ImageDraw, ImageFont, ImageChops, ImageOps
import os

# --- Configuration ---
IMAGE_SIZE = (800, 480)          # final canvas size (width, height)
FPS = 5                         # Increased for smoother typewriter
TYPEWRITER_SPEED = 5             # chars per second (5 as requested)
UPDATE_INTERVAL = 5.0            # seconds to wait after typing finishes before changing

# Font paths to try for face characters (in order of preference)
FACE_FONT_PATHS = [
    "seguisym.ttf"
]

FONT_TEXT_PATH = "./Comfortaa-Bold.ttf"

# Font sizes tuned for layout similar to the reference image
FACE_FONT_SIZE = 120  # Reduced from 160 as requested
HEADER_FONT_SIZE = 18
PROMPT_FONT_SIZE = 20
MSG_FONT_SIZE = 20
BOTTOM_FONT_SIZE = 18

# Layout metrics (tweak as needed)
MARGIN_X = 10
TOP_BAR_H = 36
BOTTOM_BAR_H = 36
MIDDLE_PADDING = 12

# Faces and sample messages
FACES = {
    'AWAKE': '( ^_^ )',
    'HAPPY': '( ^‿^ )',
    'SLEEP': '( -_- )',
    'LOOK_R': '( ⚆_⚆)',
    'LOOK_L': '(☉_☉ )',
    'COOL': '(⌐■_■)',
    'KAWAII': '( ^.^ )',
}

MESSAGES = [
    "Cool, we got 1",
    "new handshake!",
    "Scanning for networks...",
    "Learning from handshakes...",
    "Optimizing algorithms...",
    "Standing by...",
    "Ready to pwn.",
]

# --- Utility functions for font glyph detection ---

def load_font(path, size, fallback_to_default=True):
    """Load a truetype font, fall back to default PIL font if not found."""
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        if fallback_to_default:
            return ImageFont.load_default()
        raise

def font_has_glyph(pil_font, char):
    """
    Test whether the PIL ImageFont can render a specific character.
    Returns True if the character can be rendered, False otherwise.
    """
    try:
        mask = pil_font.getmask(char, mode='L')
        im = Image.frombytes('L', mask.size, bytes(mask))
        return im.getbbox() is not None
    except Exception:
        return False

def get_best_font_for_char(char, available_fonts):
    """
    Find the first font that can render the given character.
    Returns (font, font_index) or (None, -1) if no font supports the character.
    """
    for i, font in enumerate(available_fonts):
        if font_has_glyph(font, char):
            return font, i
    return None, -1

# --- UI Class ---

class PwnagotchiUI:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode(IMAGE_SIZE)
        pygame.display.set_caption("Pwnagotchi-like UI")

        # Time / sync state
        self.last_clock_sync = time.time()
        self.bulgaria_time = datetime.utcnow() + timedelta(hours=2)  # approximate EET/EEST

        # Load all available face fonts
        self.face_fonts = []
        self.face_font_names = []
        for font_path in FACE_FONT_PATHS:
            try:
                font = load_font(font_path, FACE_FONT_SIZE, fallback_to_default=False)
                self.face_fonts.append(font)
                self.face_font_names.append(os.path.basename(font_path))
                print(f"Loaded face font: {os.path.basename(font_path)}")
            except Exception as e:
                print(f"Could not load font {font_path}: {e}")
        
        # Ensure we have at least one font
        if not self.face_fonts:
            print("Warning: No face fonts loaded, using default")
            self.face_fonts = [ImageFont.load_default()]
            self.face_font_names = ["default"]
        
        # Load text fonts
        self.text_font = load_font(FONT_TEXT_PATH, MSG_FONT_SIZE)
        self.header_font = load_font(FONT_TEXT_PATH, HEADER_FONT_SIZE)
        self.prompt_font = load_font(FONT_TEXT_PATH, PROMPT_FONT_SIZE)
        self.bottom_font = load_font(FONT_TEXT_PATH, BOTTOM_FONT_SIZE)

        # Load SF-Pro-Rounded-Regular.otf for '■' only
        self.sf_pro_font = load_font("./SF-Pro-Rounded-Regular.otf", FACE_FONT_SIZE, fallback_to_default=False)

        # State
        self.current_face_key = 'AWAKE'
        self.current_face = FACES[self.current_face_key]
        self.current_message = "Welcome!"
        self.displayed_message = ""
        self.last_typewriter_update = time.time()
        self.last_blink_time = time.time()
        self.cursor_visible = True
        self.last_update_time = 0.0
        self.message_finished_time = 0.0
        self.is_typing_finished = False
        self.typewriter_chars_typed = 0

        # Initialize first state immediately
        self.update_face_and_message(force=True)

    def get_bulgaria_time_str(self):
        elapsed = time.time() - self.last_clock_sync
        now = self.bulgaria_time + timedelta(seconds=elapsed)
        return now.strftime("%H:%M:%S")
    def update_face_and_message(self, force=False):
        import requests

        def fetch_security_event():
            try:
                # 1) CISA Known Exploited Vulnerabilities (zero-days)
                kev = requests.get(
                    "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json",
                    timeout=5
                ).json()
                kev_items = kev.get("vulnerabilities", [])
                
                # 2) BreachDirectory API (recent breaches)
                bd = requests.get(
                    "https://breachdirectory.com/api/latest", timeout=5
                ).json() if False else []  # disabled unless user has a key

                # Pick message source
                if kev_items:
                    item = random.choice(kev_items)
                    title = item.get("vulnerabilityName", "Unknown vuln")
                    date = item.get("dateAdded", "Unknown date")
                    desc = f"0-day: {title} ({date})"
                    severity = "critical"
                elif bd:
                    item = random.choice(bd)
                    name = item.get("name", "Unknown org")
                    desc = f"Breach: {name}"
                    severity = "high"
                else:
                    # fallback
                    desc = "No new public exploits today."
                    severity = "low"

                return desc, severity

            except Exception:
                return "No threat intelligence available.", "low"

        # Only update once per cycle
        t = time.time()

        if force or (self.is_typing_finished and (t - self.message_finished_time) >= UPDATE_INTERVAL):
            msg, severity = fetch_security_event()

            # choose face based on severity
            if severity == "critical":
                self.current_face_key = "COOL"
            elif severity == "high":
                self.current_face_key = "LOOK_L"
            elif severity == "medium":
                self.current_face_key = "LOOK_R"
            else:
                self.current_face_key = "AWAKE"

            self.current_face = FACES[self.current_face_key]
            self.current_message = msg
            self.displayed_message = ""
            self.typewriter_chars_typed = 0
            self.last_update_time = t
            self.last_typewriter_update = time.time()
            self.is_typing_finished = False
            self.message_finished_time = 0.0


    def update_typewriter(self):
        """Fixed typewriter implementation using character count instead of slicing"""
        now = time.time()
        
        if self.typewriter_chars_typed < len(self.current_message):
            chars_to_type = int((now - self.last_typewriter_update) * TYPEWRITER_SPEED)
            if chars_to_type > 0:
                new_chars_typed = min(self.typewriter_chars_typed + chars_to_type, len(self.current_message))
                self.displayed_message = self.current_message[:new_chars_typed]
                self.typewriter_chars_typed = new_chars_typed
                self.last_typewriter_update = now
                
                # Check if typing just finished
                if self.typewriter_chars_typed == len(self.current_message):
                    self.is_typing_finished = True
                    self.message_finished_time = time.time()
        else:
            # Ensure we're showing the full message
            self.displayed_message = self.current_message

    def update_blink(self):
        now = time.time()
        if (now - self.last_blink_time) >= 0.7:
            self.cursor_visible = not self.cursor_visible
            self.last_blink_time = now

    def render_face_char_by_char(self, draw, face_text, x, y):
        """Render face text character by character using the best available font for each character."""
        current_x = x
        char_spacing = 2  # Small spacing between characters
        
        for char in face_text:
            if char == '■':
                font = self.sf_pro_font
            else:
                font, font_idx = get_best_font_for_char(char, self.face_fonts)
                if font is None and not char == " ":
                    # No font supports this character - use first font and print warning
                    font = self.face_fonts[0]
                    print(f"WARNING: Character '{char}' (U+{ord(char):04X}) not supported by any available font!")
            # Get character metrics
            bbox = draw.textbbox((0, 0), char, font=font)
            char_width = bbox[2] - bbox[0]
            # Draw the character
            draw.text((current_x, y), char, font=font, fill="black")
            # Move to next position
            current_x += char_width + char_spacing
        
        return current_x

    def render_layout(self):
        """
        Build the full screen image using PIL, following the reference layout:
        - Top bar: left label + right UP time, thin horizontal rule
        - Middle: prompt (hawking> █) and message on the right, face large on left
          (face occupies left area; prompt/message top-right)
        - Bottom: horizontal rule then PWND status
        """
        img = Image.new("RGB", IMAGE_SIZE, "white")
        draw = ImageDraw.Draw(img)

        w, h = IMAGE_SIZE

        # --- Top bar ---
        top_left = "CH *  APS 4 (9)"
        top_right = "UP " + self.get_bulgaria_time_str()
        draw.text((MARGIN_X, 6), top_left, font=self.header_font, fill="black")
        tr_size = draw.textbbox((0,0), top_right, font=self.header_font)
        draw.text((w - MARGIN_X - (tr_size[2]-tr_size[0]), 6), top_right, font=self.header_font, fill="black")

        # horizontal rule under top bar
        rule_y = TOP_BAR_H - 6
        draw.line([(MARGIN_X, rule_y), (w - MARGIN_X, rule_y)], fill="black", width=2)

        # --- Middle area geometry ---
        middle_top = TOP_BAR_H + MIDDLE_PADDING
        middle_bottom = h - BOTTOM_BAR_H - MIDDLE_PADDING
        middle_h = middle_bottom - middle_top

        # Left area for face: use about 55% of width for face area, right area for text prompt/message
        # But move face more to the right by reducing left area width
        left_area_w = int(w * 0.45)  # Reduced from 0.55 to move face right
        right_area_x = left_area_w + MARGIN_X

        # --- Face rendering using per-character font selection ---
        face_text = self.current_face

        # Estimate total face width for centering
        total_width = 0
        for char in face_text:
            font, _ = get_best_font_for_char(char, self.face_fonts)
            if font is None:
                font = self.face_fonts[0]
            bbox = draw.textbbox((0, 0), char, font=font)
            total_width += (bbox[2] - bbox[0]) + 2  # char width + spacing
        
        # Calculate starting position (centered in left area with right offset)
        face_x_offset = 40  # Additional offset to move face right
        face_x = int((left_area_w - total_width) / 2) + face_x_offset
        face_y = middle_top + int((middle_h - FACE_FONT_SIZE) / 2)
        
        # Render the face character by character
        self.render_face_char_by_char(draw, face_text, face_x, face_y)

        # --- Prompt and message on the right area ---
        prompt = "AI> "
        # Draw prompt top-right area (slightly inset)
        prompt_x = right_area_x
        prompt_y = middle_top + 8
        
        try:
            draw.text((prompt_x, prompt_y), prompt, font=self.prompt_font, fill="black")
        except Exception:
            # Fallback if font fails
            pass

        # Draw a block cursor square right after prompt (solid rectangle)
        # measure prompt width
        try:
            p_bbox = draw.textbbox((0,0), prompt, font=self.prompt_font)
            p_w = p_bbox[2] - p_bbox[0]
            cursor_size = self.prompt_font.size  # roughly height
        except Exception:
            p_w = len(prompt) * PROMPT_FONT_SIZE // 2
            cursor_size = PROMPT_FONT_SIZE
            
        cursor_margin = 6
        cursor_x = prompt_x + p_w + 4
        cursor_y = prompt_y
        if self.cursor_visible and not self.is_typing_finished:
            draw.rectangle([cursor_x, cursor_y, cursor_x + (cursor_size//2), cursor_y + cursor_size], fill="black")

        # Message: displayed_message (typewriter) drawn below prompt, with wrapping to match reference
        msg_x = right_area_x
        msg_y = prompt_y + self.prompt_font.size + 6

        # Break displayed_message into lines with reasonable wrap width (use right side area width)
        right_area_w = w - right_area_x - MARGIN_X
        
        # Simple word-wrapping routine
        def wrap_text(text, font, max_width):
            lines = []
            for paragraph in text.split("\n"):
                words = paragraph.split(" ")
                cur = ""
                for word in words:
                    test = (cur + " " + word).strip() if cur else word
                    try:
                        bbox = draw.textbbox((0,0), test, font=font)
                        test_w = bbox[2] - bbox[0]
                    except Exception:
                        test_w = len(test) * MSG_FONT_SIZE // 2
                        
                    if test_w <= max_width:
                        cur = test
                    else:
                        if cur:
                            lines.append(cur)
                        cur = word
                if cur:
                    lines.append(cur)
            return lines

        try:
            lines = wrap_text(self.displayed_message if self.displayed_message else self.current_message, self.text_font, right_area_w)
        except Exception:
            # Fallback wrapping
            lines = []
            text = self.displayed_message if self.displayed_message else self.current_message
            for paragraph in text.split("\n"):
                while len(paragraph) > 0:
                    if len(paragraph) <= 20:
                        lines.append(paragraph)
                        break
                    else:
                        lines.append(paragraph[:20])
                        paragraph = paragraph[20:]
        
        for i, line in enumerate(lines[:6]):  # limit number of lines shown
            try:
                draw.text((msg_x, msg_y + i * (self.text_font.size + 6)), line, font=self.text_font, fill="black")
            except Exception:
                # Fallback drawing
                pass

        # --- Bottom horizontal rule and status line ---
        bottom_rule_y = h - BOTTOM_BAR_H + 6
        draw.line([(MARGIN_X, bottom_rule_y), (w - MARGIN_X, bottom_rule_y)], fill="black", width=2)

        bottom_text = "PWND 1 (18) [PS4-086313EAB731]"
        try:
            bottom_text_bbox = draw.textbbox((0,0), bottom_text, font=self.bottom_font)
            # place bottom text slightly above bottom of image, left aligned
            bt_x = MARGIN_X
            bt_y = bottom_rule_y + 6
            draw.text((bt_x, bt_y), bottom_text, font=self.bottom_font, fill="black")
        except Exception:
            # Fallback drawing
            pass

        return img

    def pil_to_pygame(self, pil_img):
        """Convert PIL image to a pygame surface (RGB)"""
        mode = pil_img.mode
        size = pil_img.size
        data = pil_img.tobytes()
        return pygame.image.fromstring(data, size, mode)

    def run(self):
        # Detect if we're on Linux (specifically targeting Raspbian Lite)
        is_linux = os.name == 'posix' and os.uname().sysname == 'Linux'
        use_framebuffer = False
        fb_device = None
        
        if is_linux:
            # Try to use framebuffer directly for Raspbian Lite
            try:
                # Common framebuffer devices
                for fb_dev in ['/dev/fb0', '/dev/fb1']:
                    if os.path.exists(fb_dev):
                        fb_device = open(fb_dev, 'wb')
                        use_framebuffer = True
                        print(f"Using framebuffer device: {fb_dev}")
                        break
                
                if not use_framebuffer:
                    print("No framebuffer device found, falling back to pygame display")
                    
            except Exception as e:
                print(f"Failed to open framebuffer: {e}, falling back to pygame display")
                use_framebuffer = False

        # Initialize pygame only if not using framebuffer
        if not use_framebuffer:
            clock = pygame.time.Clock()
        
        running = True
        
        def signal_handler(sig, frame):
            nonlocal running
            running = False
        
        # Set up Ctrl+C handler
        try:
            import signal
            signal.signal(signal.SIGINT, signal_handler)
        except ImportError:
            pass  # signal module not available on all platforms

        try:
            while running:
                # Handle events only if using pygame display
                if not use_framebuffer:
                    for ev in pygame.event.get():
                        if ev.type == pygame.QUIT:
                            running = False
                        elif ev.type == pygame.KEYDOWN:
                            if ev.key == pygame.K_ESCAPE:
                                running = False

                # Update only after typing finished and 5 seconds have passed
                self.update_face_and_message()

                # Update animations
                self.update_typewriter()
                self.update_blink()

                # Render the image
                pil_img = self.render_layout()

                if use_framebuffer and fb_device:
                    # Convert PIL image to raw framebuffer format and write directly
                    # Framebuffer typically expects RGB565 for 16bpp or BGR/BGRX for 24/32bpp
                    # We'll use RGB888 and let the framebuffer driver handle conversion
                    rgb_img = pil_img.convert('RGB')
                    raw_data = rgb_img.tobytes()
                    
                    try:
                        fb_device.seek(0)
                        fb_device.write(raw_data)
                        fb_device.flush()
                    except Exception as e:
                        print(f"Framebuffer write error: {e}")
                        use_framebuffer = False
                        if fb_device:
                            fb_device.close()
                            fb_device = None
                
                else:
                    # Use pygame display
                    surf = self.pil_to_pygame(pil_img)
                    self.screen.blit(surf, (0, 0))
                    pygame.display.flip()
                    clock.tick(FPS)

        except KeyboardInterrupt:
            print("\nCtrl+C received, exiting...")
        finally:
            # Cleanup
            if use_framebuffer and fb_device:
                try:
                    fb_device.close()
                except:
                    pass
            if not use_framebuffer:
                pygame.quit()


if __name__ == "__main__":
    ui = PwnagotchiUI()
    ui.run()