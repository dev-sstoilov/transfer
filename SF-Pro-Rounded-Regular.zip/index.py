﻿import pygame
import time
import random
from datetime import datetime, timedelta
from PIL import Image, ImageDraw, ImageFont
import os
import requests

# --- Configuration ---
FPS = 5
TYPEWRITER_SPEED = 5
UPDATE_INTERVAL = 5.0

FACE_FONT_PATHS = ["seguisym.ttf"]
FONT_TEXT_PATH = "./Comfortaa-Bold.ttf"
FACE_FONT_SIZE = 120
HEADER_FONT_SIZE = 18
PROMPT_FONT_SIZE = 20
MSG_FONT_SIZE = 20
BOTTOM_FONT_SIZE = 18
MARGIN_X = 10
TOP_BAR_H = 36
BOTTOM_BAR_H = 36
MIDDLE_PADDING = 12

FACES = {
    'AWAKE': '( ^_^ )',
    'HAPPY': '( ^‿^ )',
    'SLEEP': '( -_- )',
    'LOOK_R': '( ⚆_⚆)',
    'LOOK_L': '(☉_☉ )',
    'COOL': '(⌐■_■)',
    'KAWAII': '( ^.^ )',
}

# ---------------------------------------------------------------------
# Font utilities
# ---------------------------------------------------------------------
def load_font(path, size, fallback=True):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        if fallback:
            return ImageFont.load_default()
        raise

def font_has_glyph(pil_font, char):
    try:
        mask = pil_font.getmask(char, mode='L')
        im = Image.frombytes('L', mask.size, bytes(mask))
        return im.getbbox() is not None
    except Exception:
        return False

def get_best_font_for_char(char, fonts):
    for f in fonts:
        if font_has_glyph(f, char):
            return f
    return None

# ---------------------------------------------------------------------
# Pwnagotchi UI
# ---------------------------------------------------------------------
class PwnagotchiUI:
    def __init__(self):
        # Force framebuffer driver for headless Pi
        os.environ["SDL_VIDEODRIVER"] = "fbcon"
        os.environ["SDL_FBDEV"] = "/dev/fb0"
        os.environ["SDL_NOMOUSE"] = "1"

        pygame.init()
        self.screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
        self.width, self.height = self.screen.get_size()
        pygame.display.set_caption("Pwnagotchi HDMI UI")

        self.last_clock_sync = time.time()
        self.bulgaria_time = datetime.utcnow() + timedelta(hours=2)

        # Load fonts
        self.face_fonts = [load_font(fp, FACE_FONT_SIZE, fallback=False) for fp in FACE_FONT_PATHS if os.path.exists(fp)]
        if not self.face_fonts:
            self.face_fonts = [ImageFont.load_default()]

        self.text_font = load_font(FONT_TEXT_PATH, MSG_FONT_SIZE)
        self.header_font = load_font(FONT_TEXT_PATH, HEADER_FONT_SIZE)
        self.prompt_font = load_font(FONT_TEXT_PATH, PROMPT_FONT_SIZE)
        self.bottom_font = load_font(FONT_TEXT_PATH, BOTTOM_FONT_SIZE)
        self.sf_pro_font = load_font("./SF-Pro-Rounded-Regular.otf", FACE_FONT_SIZE, fallback=False)

        self.current_face_key = 'AWAKE'
        self.current_face = FACES[self.current_face_key]
        self.current_message = "Welcome!"
        self.displayed_message = ""
        self.typewriter_chars_typed = 0
        self.is_typing_finished = False
        self.last_typewriter_update = time.time()
        self.message_finished_time = 0
        self.cursor_visible = True
        self.last_blink_time = time.time()

        self.update_face_and_message(force=True)

    # ... Keep all methods as before ...
    # get_bulgaria_time_str, update_face_and_message, update_typewriter,
    # update_blink, render_face_char_by_char, render_layout, pil_to_pygame

    # -------------------------
    def run(self):
        clock = pygame.time.Clock()
        running = True
        while running:
            for ev in pygame.event.get():
                if ev.type==pygame.QUIT or (ev.type==pygame.KEYDOWN and ev.key==pygame.K_ESCAPE):
                    running=False

            self.update_face_and_message()
            self.update_typewriter()
            self.update_blink()

            surf = self.pil_to_pygame(self.render_layout())
            self.screen.blit(surf,(0,0))
            pygame.display.flip()
            clock.tick(FPS)
        pygame.quit()

# ---------------------------------------------------------------------
if __name__=="__main__":
    PwnagotchiUI().run()
